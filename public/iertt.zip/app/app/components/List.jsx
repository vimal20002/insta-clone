'use client'
import Cardd from "./Card"

import Box from "@mui/material/Box";
import DetailBox from "./DetailBox";
import { useState } from "react";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import Link from "next/link";
import { Chip } from "@mui/material";
const db = [
    {
        name:"Avichal Dubey",
        rank:57,
        score:700,
        year:"3rd",
        branch:"CSE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    },
    {
        name:"Harry",
        rank:200,
        score:600,
        year:"3rd",
        branch:"ECE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    },
    {
        name:"Potter",
        rank:1200,
        score:600,
        year:"4th",
        branch:"CSE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    },
    {
        name:"Iron Man",
        rank:1700,
        score:580,
        year:"4th",
        branch:"CSE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    },
    {
        name:"Parag",
        rank:4000,
        score:400,
        year:"4th",
        branch:"CSE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    },
     {
        name:"Sanju",
        rank:2000,
        score:500,
        year:"3rd",
        branch:"CSE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    } ,
    {
        name:"Anil",
        rank:400,
        score:610,
        year:"3rd",
        branch:"ECE",
        uri : "https://drive.google.com/file/d/1iOudU1dFmiQEWw8iTZdf_YurE8rMVj-G/preview"
    }
]
const filtersData=["3rd Year", "4th Year", "CSE", "ECE", "EE", "IP", "ICE", "Mech", "Civil", "Under 100", "Under 1000", "Under 5000"]

const Listt = ()=>{
    const [open, setOpen] = useState(false);
    const [data, setData] = useState({})
    const [dt, setDt] = useState(db);
    const [arr, setArr] = useState([])
    const [flag, setFlag] = useState(true)
    const fun=(prp, check, db, setDt)=>{
        // console.log(prp, check, db)
        setDt(db?.filter((e)=>{
            console.log(e[prp], check)
            return e[prp] === check
        }))
    }
    const fun2 = (val, db, setDt)=>{
        setDt(db?.filter((e)=>{
            return e.rank <= val;
        }))
    }
    const handleClear = ()=>{
        setDt(db);
        setArr([]);
    }
    const handleFilter= (val, dt)=>{
        switch (val)
        {
            case "3rd Year":
                fun("year", "3rd", dt, setDt)
                break;
            case "4th Year":
                fun("year", "4th", dt, setDt)
                break;
            case "CSE":
                fun("branch", "CSE", dt, setDt)
                break;
            case "ECE":
                fun("branch", "ECE", dt, setDt)
                break;
            case "EE":
                fun("branch", "EE", dt, setDt)
                break;
            case "IP":
                fun("branch", "IP", dt, setDt)
                break;
            case "ICE":
                fun("branch", "ICE", dt, setDt)
                break;
            case "Mech":
                fun("branch", "Mech", dt, setDt)
                break;
            case "Civil":
                fun("branch", "Civil", dt, setDt)
                break;
            case "Under 100":
                fun2(100, dt, setDt)
                break;
            case "Under 1000":
                fun2(1000,  dt, setDt)
                break;
            case "Under 5000":
                fun2(5000 , dt, setDt)
                break;
        }
    }
    const handleAdd=(val)=>{
        const a = arr;

        a.push(val)
        console.log(a)
        a?.forEach((e, idx) => {
            const b = idx == 0?db :dt;
            handleFilter(e, b)
        });
        setArr(a)
        setFlag(!flag)
    }
    const handleRem = (val)=>{
        const a = arr?.filter((e)=>{return e !== val});
        console.log(a)
        if(a.length === 0)handleClear()
        
        a?.forEach((e, idx )=> {
            const b = idx == 0?db :dt;
            handleFilter(e, b)
        });
        setArr(a)
        setFlag(!flag)
    }
    const check = (val)=>{
        const a = arr.filter((e)=>{
            return e === val
        })
        return a.length == 0
    }
return(
    <>
    <Link href="https://iert.ac.in">
    <ArrowBackIcon  className="back"/>
    </Link>
    <div className="main">
    <DetailBox open={open} setOpen={setOpen} data={data}/>
    <h2 className='head'>Our GATE 2024 Rankers</h2>
    <div className="filters">
        {
            filtersData?.map((str)=>{
                const flag = check(str);
                return <Chip label={str} className={flag?``:'act'} onClick={()=>{
                    flag?handleAdd(str):handleRem(str)
                }} />
            })
        }
          <Chip label="Clear" color="primary" onClick = {handleClear} />
    
    </div>
        <Box sx={{ display: "flex", flexWrap: "wrap", rowGap:"20px", columnGap:"30px", justifyContent:"center", alignItems:"center"}}>
            {dt.map((e)=>{
                return <Cardd setData = {setData} key={e.rank} obj={e} setOpen = {setOpen}/>
            })}
        </Box>
        </div>
    </>
)
}
export default Listt