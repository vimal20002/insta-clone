import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Paper from '@mui/material/Paper';
import Draggable from 'react-draggable';

function PaperComponent(props) {
  return (
    <Draggable
      handle="#draggable-dialog-title"
      cancel={'[class*="MuiDialogContent-root"]'}
    >
      <Paper {...props} />
    </Draggable>
  );
}

export default function DetailBox({data, open, setOpen}) {

//   const handleClickOpen = () => {
//     setOpen(true);
//   };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Dialog
      
        open={open}
        onClose={handleClose}
        PaperComponent={PaperComponent}
        aria-labelledby="draggable-dialog-title"
      >
        <DialogTitle style={{ cursor: 'move', textAlign:"center" }} id="draggable-dialog-title">
          {data.name}
        </DialogTitle>
        <DialogContent>
          <DialogContentText className='detailbox'>
            <span className="dtl">Rank : {data.rank}</span>
            <span className="dtl">GATE Score : {data.score}</span>
            <span className="dtl">Branch : {data.branch}</span>
            <span className="dtl">Year : {data.year}</span>
            <iframe src={data.uri} width="300" height="380" allow="autoplay"></iframe>          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button autoFocus onClick={handleClose}>
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}