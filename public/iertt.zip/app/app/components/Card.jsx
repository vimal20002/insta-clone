import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

export default function Cardd({obj, setData, setOpen}) {
  return (
    <div className="crd" onClick={()=>{
      console.log("fdd")
      setData(obj);setOpen(true)}}>
          <Card sx={{ maxWidth: 345 }} >
      <CardActionArea>
        <CardMedia
          component="img"
          height="270"
          image="https://img.freepik.com/free-photo/young-bearded-man-with-striped-shirt_273609-5677.jpg"
          alt="green iguana"
          className='imgg'
          onClick={()=>{
            console.log("d")
            setData(obj);setOpen(true)}}
        />
        <CardContent sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                flexDirection: 'column'
            }}>
          <Typography gutterBottom variant="h6" component="div" sx={{
            color:"blue"
          }}>
            AIR : {obj.rank}
          </Typography>
          <Typography variant="h7"  >
            {obj.name}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
    </div>

  );
}