
import Listt from "./components/List";


export default function Home() {
  return (
    <>
 
    <Listt/>
    </>
  );
}
